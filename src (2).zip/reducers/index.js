import {
    combineReducers
} from 'redux';

import user from './auth';
import post from './post';
import qna from './qna';
import answer from './answer';

export default combineReducers({
    user,
    post,
    qna,
    answer
});