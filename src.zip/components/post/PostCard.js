import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { message, Card, Popover, Button, Avatar, List, Comment, Modal, Input } from 'antd';
import {
    RetweetOutlined, HeartOutlined, MessageOutlined, EllipsisOutlined, HeartTwoTone,
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { POST_DELETE_REQUEST } from '../../actions/types';
import { Route, Link, withRouter } from 'react-router-dom';
moment.locale('ko')
const PostCard = ({ post, history }) => {
    const dispatch = useDispatch();
    const id = useSelector((state) => state.user.me?.id);
    const removePostLoading = useSelector((state) => state.post.deletePostsLoading);
    const onRemovePost = useCallback(() => {
        if (!id) {
            return alert('로그인이 필요합니다.');
        }
        return dispatch({
            type: POST_DELETE_REQUEST,
            data: { postId: post.id }
        });
    }, [id, post]);

    const onUpdate = useCallback(() => {
        if (!id) {
            return alert('로그인이 필요합니다.');
        }
        history.replace(`/post/${post.id}`);
    }, [id, post]);

    return (
        <div style={{ marginBottom: 20 }}>

            <Card
                // cover={post.PImages[0] && <PostImage images={post.Images} />}
                actions={[

                    <Popover
                        key="more"
                        content={(
                            <Button.Group>
                                {id && post.User.id === id || post.User.role === 'admin'
                                    ? (
                                        <>

                                            <Button type="danger" loading={removePostLoading} onClick={onRemovePost}>삭제</Button>
                                            <Button type="primary" onClick={onUpdate}>업데이트</Button>
                                        </>
                                    )
                                    : <></>}
                            </Button.Group>
                        )}
                    >
                        <EllipsisOutlined />
                    </Popover>,
                ]}


            >
                <p>{post.title}</p>
                <p>{post.content}</p>
                <p>{moment(post.createdAt).format('YYYY.MM.DD')}</p>

            </Card>

        </div>
    );
};

PostCard.propTypes = {

};

export default withRouter(PostCard);