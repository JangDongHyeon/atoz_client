import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Route, Redirect } from 'react-router-dom';


const PrivateRoute = ({ component: Component, ...rest }) => {
    const { me } = useSelector((state) => state.user);
    const [status, setStatus] = useState(null);
    // console.log(status)
    // async function getStatus() {
    //     if (localStorage.getItem('token')) {
    //         try {

    //             axios.defaults.headers.common['Authorization'] = localStorage.getItem('token').trim();
    //             const res = await axios.get(
    //                 '/user/me',
    //                 { headers: { 'Content-Type': 'application/json' } },
    //             );

    //             if (res.data.id) {
    //                 console.log('222222222222222222222222222222')
    //                 return 200;
    //             } else {
    //                 localStorage.removeItem('token');
    //                 return 401;
    //             }
    //         } catch (err) {
    //             localStorage.removeItem('token');
    //             return 500;
    //         }
    //     }
    //     else return 500;
    // }
    // useEffect(() => {
    //     (async () => setStatus(await getStatus()))();
    // }, []);

    return me && (<Route {...rest} render={props => (me ? <Component {...props} /> : <Redirect to="/signin" />)} />)
};



export default PrivateRoute;