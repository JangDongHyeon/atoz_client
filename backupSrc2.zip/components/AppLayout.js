import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Link, } from 'react-router-dom';
import { Menu, Modal, Button, Dropdown, Avatar } from 'antd';

import { useSelector } from 'react-redux';

import { MenuOutlined, UserOutlined, } from '@ant-design/icons';

import atoz_logo from '../assets/atoz_logo.png'
// import LoginForm from './LoginForm';
import { useMediaQuery } from "react-responsive"
import Signin from './sign/Signin'

const AppLayout = ({ children }) => {
    const { me } = useSelector((state) => state.user);
    const isPc = useMediaQuery({
        query: "(min-width:1024px)"
    });
    const isTablet = useMediaQuery({
        query: "(min-width:768px) and (max-width:1023px)"
    });
    const isMobile = useMediaQuery({
        query: "(max-width:767px)"
    });

    const [isModalVisible, setIsModalVisible] = useState(false);

    const showModal = () => {
        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };
    const modalLoginView = () => {
        return (

            <Modal title="로그인" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel} width={450}>
                <Signin />
            </Modal>
        )

    }
    const dropDownMenu = () => (

        <Menu style={{ width: '150px', backgroundColor: '#f1f1f1' }}>
            <Menu.Item key="setting:1"><Link to="/service">AI배송기간 예측</Link></Menu.Item>
            <Menu.Item key="setting:2">메뉴1</Menu.Item>
            <Menu.Item key="setting:2">고객지원</Menu.Item>

        </Menu>
    )
    console.log(me)
    return (
        <div className=''>
            {/*****************************************header*********************************/}
            {(isPc || isTablet) &&
                <Menu mode="horizontal" className='headerContainer'>
                    <Menu.Item>
                        <Link to="/"><img className='logoImage' src={atoz_logo} /></Link>
                    </Menu.Item>
                    <Menu.Item>
                        <Link to="/service">AI배송기간 예측</Link>
                    </Menu.Item>
                    <Menu.Item>
                        <Link to="/profile">메뉴1</Link>
                    </Menu.Item>
                    <Menu.Item>
                        <Link to="/profile">고객지원</Link>
                    </Menu.Item>

                    <Menu.Item style={{ position: 'absolute', top: 0, right: 80 }}>
                        <Link to="/profile">나의배송</Link>
                    </Menu.Item>
                    <Menu.Item style={{ position: 'absolute', top: 0, right: 0 }}>
                        {/* <Link to="/signin">로그인</Link> */}
                        {me ? <button className='nudeButton' onClick={showModal}><Avatar style={{ color: '#1C4FA1', backgroundColor: '#AEE2FF' }}>{me.name}</Avatar></button> : <button className='nudeButton' onClick={showModal}> 로그인</button>}
                    </Menu.Item>
                </Menu>
            }
            {isMobile &&
                <div className='headerContainerM'>

                    <Dropdown overlay={dropDownMenu} placement="bottomLeft" trigger={['click']}>
                        <Button style={{ border: 'none', }}><MenuOutlined style={{ fontSize: 18, marginLeft: 10 }} /></Button>
                    </Dropdown>
                    <Link to="/"><img className='logoImage' src={atoz_logo} /></Link>

                    <button className='nudeButton' onClick={showModal}><UserOutlined style={{ marginRight: 10, fontSize: 18 }} /></button>
                </div>
            }

            {/*****************************************contents*********************************/}

            <div className='contentContainer'>
                {children}
            </div>
            {modalLoginView()}

            {/*****************************************foter***********************************/}
            <div className='footerContainer'>
                <p>bbbbbbb</p>
            </div>
        </div>
    );
};

AppLayout.propTypes = {
    children: PropTypes.node.isRequired,
};

export default AppLayout;