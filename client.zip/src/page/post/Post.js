import React, { useEffect, } from 'react';

import AppLayout from '../../components/AppLayout';
import { useDispatch, useSelector } from 'react-redux';
import { POST_GET_REQUEST } from '../../actions/types';
import PostCard from '../../components/post/PostCard';

const defaultPage = 1;
const defaultPageSize = 10;

const Post = props => {
    const dispatch = useDispatch();
    const { me } = useSelector((state) => state.user);
    const { loadPostsDone, loadPostsLoading, loadPostsError, posts, psize, hasMorePosts } = useSelector((state) => state.post);


    useEffect(() => {

        dispatch({
            type: POST_GET_REQUEST,
            data: { check: false, lastId: 0 }
        })
    }, [])

    useEffect(() => {
        function onScroll() {
            if (window.pageYOffset + document.documentElement.clientHeight > document.documentElement.scrollHeight - 300) {

                if (hasMorePosts && !loadPostsLoading) {

                    const lastId = posts[posts.length - 1]?.id;
                    dispatch({
                        type: POST_GET_REQUEST,
                        data: { lastId, check: true },
                    });
                }
            }
        }
        window.addEventListener('scroll', onScroll);
        return () => {
            window.removeEventListener('scroll', onScroll);
        };
    }, [hasMorePosts, loadPostsLoading, posts]);



    return me && (
        <AppLayout>

            {posts.map((post, i) => <PostCard key={i} post={post} />)}
        </AppLayout>
    );
};

Post.propTypes = {

};

export default Post;