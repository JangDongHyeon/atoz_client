import React, { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Link, Redirect, withRouter } from 'react-router-dom';
import { Menu, Modal, Button, Col, Dropdown, Avatar } from 'antd';

import { useDispatch, useSelector } from 'react-redux';

import { MenuOutlined, UserOutlined, DownOutlined, SettingOutlined, CustomerServiceOutlined, SnippetsOutlined, DeploymentUnitOutlined,QuestionCircleOutlined } from '@ant-design/icons';
import UserProfile from './UserProfile';
import atoz_logo from '../assets/atoz_logo.png'
import aiicon from '../assets/aiicon.png'
// import LoginForm from './LoginForm';
import { useMediaQuery } from "react-responsive"
import Signin from './sign/Signin'
import { LOG_OUT_REQUEST } from '../actions/types';

const AppLayout = ({ children, history }) => {
    // const { me } = useSelector((state) => state.user);
    const isPc = useMediaQuery({
        query: "(min-width:1024px)"
    });
    const isTablet = useMediaQuery({
        query: "(min-width:768px) and (max-width:1023px)"
    });
    const isMobile = useMediaQuery({
        query: "(max-width:767px)"
    });
    const dispatch = useDispatch();
    const { me, logOutLoading } = useSelector((state) => state.user);

    const onLogOut = useCallback((e) => {
        dispatch({
            type: LOG_OUT_REQUEST
        });
    }, []);
    const profileClick = useCallback((e) => {
        // history.replace('/profile')
    }, []);

    const { SubMenu } = Menu;
    const [isModalVisible, setIsModalVisible] = useState(false);

    const showModal = () => {
        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };
    const modalLoginView = () => {
        return (

            <Modal title="로그인" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel} width={450}>
                <Signin handleOk={handleOk} />
            </Modal>
        )

    }
    const dropDownMenu = () => (

        <Menu style={{ width: '150px', backgroundColor: '#f1f1f1' }}>
            <Menu.Item key="1"><Link to="/service">AI배송기간 예측</Link></Menu.Item>
            <Menu.Item key="2">메뉴1</Menu.Item>
            <Menu.Item key="3">
                <Link to="/post">고객지원</Link>
            </Menu.Item>
            <SubMenu key="SubMenu" icon={<CustomerServiceOutlined />} title="고객지원" >
                <Menu.Item key="4">
                    <Link to="/post">공지사항</Link>
                </Menu.Item>
                <Menu.Item key="5">
                    <Link to="/faq">자주하는질문</Link>
                </Menu.Item>
            </SubMenu>
        </Menu>
    )
    const dropDownMenuAdminM =()=>(
        <Menu style={{ width: '150px', backgroundColor: '#f1f1f1' }}>
        <Menu.Item key="1"><Link to="/invoice">조회내역</Link></Menu.Item>
        <Menu.Item key="2"><Link to="/qna">Q&A관리</Link></Menu.Item>
        <Menu.Item key="3"><Link to="/post">통계</Link></Menu.Item>
        <Menu.Item  key="4">
            <button className='nudeButton' style={{marginLeft:-5}} onClick={(e) => onLogOut(e)}>로그아웃</button>
        </Menu.Item>
    </Menu>
    )
    const dropDownMenuUserM =()=>(
        <Menu style={{ width: '150px', backgroundColor: '#f1f1f1' }}>
        <Menu.Item key="1"><Link to="/invoice">나의배송</Link></Menu.Item>
        <Menu.Item key="2"><Link to="/qna">자주하는질문</Link></Menu.Item>
        <Menu.Item  key="4">
            <button className='nudeButton' style={{marginLeft:-5}} onClick={(e) => onLogOut(e)}>로그아웃</button>
        </Menu.Item>
    </Menu>
    )
    
    return (
        <div className=''>
            {/*****************************************header*********************************/}
            {(isPc || isTablet) &&
                <Menu mode="horizontal" className='headerContainer'>
                    <Menu.Item  key="1">
                        <Link to="/"><img className='logoImage' src={atoz_logo} /></Link>
                    </Menu.Item>
                    <Menu.Item key="2" icon={<DeploymentUnitOutlined />} >
                        <Link to="/service">AI배송기간 예측</Link>
                    </Menu.Item>
                    <Menu.Item key="3" icon={<MenuOutlined />}>
                        <Link to="/profile" >메뉴</Link>
                    </Menu.Item>
                    <SubMenu key="SubMenu" icon={<CustomerServiceOutlined />} title="고객지원" onTitleClick={(e) => history.replace('/post')}>
                        <Menu.Item key="4" icon={<SnippetsOutlined />}>
                            <Link to="/post">공지사항</Link>
                        </Menu.Item>
                        <Menu.Item key="5" icon={<QuestionCircleOutlined/>}>
                            <Link to="/faq">자주하는질문</Link>
                        </Menu.Item>
                    </SubMenu>

                    {/* {me &&
                        <Menu.Item  key="6"style={{ position: 'absolute', top: 0, right: 80 }}>
                            <button className='nudeButton' onClick={(e) => onLogOut(e)}>로그아웃</button>
                        </Menu.Item>
                    } */}
                    {me && me.role == 'admin' &&
                        <SubMenu style={{ position: 'absolute', right: 0, }} onTitleClick={(e) => history.replace('/invoice')} key="SubMenu2" icon={<Avatar style={{ color: '#1C4FA1', backgroundColor: '#AEE2FF', marginRight: 0, marginLeft: 0 }}>{me.name}</Avatar>}>
                            <Menu.Item key="7">
                                <Link to="/invoice">조회내역</Link>
                            </Menu.Item>
                            <Menu.Item key="8">
                                <Link to="/qna">QnA관리</Link>
                            </Menu.Item>
                            <Menu.Item key="9">
                                <Link to="/faq">통계</Link>
                            </Menu.Item>
                            <Menu.Item  key="10">
                                <button className='nudeButton' style={{marginLeft:-5}} onClick={(e) => onLogOut(e)}>로그아웃</button>
                            </Menu.Item>
                        </SubMenu>
                    }
                    {me && me.role != 'admin' &&
                        <SubMenu style={{ position: 'absolute', right: 0, }} key="SubMenu2" icon={<Avatar style={{ color: '#1C4FA1', backgroundColor: '#AEE2FF', marginRight: 0, marginLeft: 0 }}>{me.name}</Avatar>}>
                            <Menu.Item key="7">
                                <Link to="/post">나의배송</Link>
                            </Menu.Item>
                            <Menu.Item key="8">
                                <Link to="/faq">자주하는질문</Link>
                            </Menu.Item>
                        </SubMenu>
                    }
                    {!me &&
                        <Menu.Item  key="12"style={{ position: 'absolute', right: 0, }}>
                            <button className='nudeButton' onClick={showModal}> 로그인</button>

                            {/* <button className='nudeButton'  onClick={(e) => onLogOut(e)} loading={logOutLoading}>로그아웃</button> */}
                        </Menu.Item>
                    }

                    {/* </Menu.Item> */}
                </Menu>
            }
            {isMobile &&
                <div className='headerContainerM'>

                    <Dropdown overlay={dropDownMenu} placement="bottomLeft" trigger={['click']}>
                        <button className='nudeButton'><MenuOutlined style={{ fontSize: 18, marginLeft: 10 }} /></button>
                    </Dropdown>
                    <Link to="/"><img className='logoImage' src={atoz_logo} /></Link>

                    {me && me.role == 'admin' &&
                        <Dropdown overlay={dropDownMenuAdminM} placement="bottomLeft" trigger={['click']}>
                            <Avatar style={{ color: '#1C4FA1', backgroundColor: '#AEE2FF', marginRight: 10, marginLeft: 0 }}>{me.name}</Avatar>
                        </Dropdown>
                    }
                    {me && me.role != 'admin' &&
                        <Dropdown overlay={dropDownMenuUserM} placement="bottomLeft" trigger={['click']}>
                            <Avatar style={{ color: '#1C4FA1', backgroundColor: '#AEE2FF', marginRight: 10, marginLeft: 0 }}>{me.name}</Avatar>
                        </Dropdown>
                    }
                    {!me &&
                            <button className='nudeButton' onClick={showModal}> 로그인</button>
                    }
                    
                </div>
            }

            {/*****************************************contents*********************************/}

            <div className='contentContainer'>
                {children}
            </div>
            {modalLoginView()}

            {/*****************************************foter***********************************/}
            <div className='footerContainer'>
                <p>bbbbbbb</p>
            </div>
        </div>
    );
};

AppLayout.propTypes = {
    children: PropTypes.node.isRequired,
};

export default withRouter(AppLayout);