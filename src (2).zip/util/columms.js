export const columns = [
    {
        title: 'Id',
        dataIndex: 'id',
        key: 'id'
    },
    {
        title: '제목',
        dataIndex: 'title',
        key: 'title'
    },
    {
        title: '내용',
        dataIndex: 'content',
        key: 'content'
    },

];

