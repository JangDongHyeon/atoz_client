import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { message, Card, Popover, Button, Avatar, List, Modal, Input, Comment } from 'antd';
import {
    RetweetOutlined, HeartOutlined, MessageOutlined, EllipsisOutlined, HeartTwoTone,
} from '@ant-design/icons';
import { useDispatch, useSelector } from 'react-redux';
import { QNA_DELETE_REQUEST } from '../../actions/types';
import { Route, Link } from 'react-router-dom';
moment.locale('ko')
const QnaCard = ({ qna }) => {
    const dispatch = useDispatch();
    const id = useSelector((state) => state.user.me?.id);
    const removeQnaLoading = useSelector((state) => state.qna.deleteQnasLoading);
    const onRemoveQna = useCallback(() => {
        if (!id) {
            return alert('로그인이 필요합니다.');
        }
        return dispatch({
            type: QNA_DELETE_REQUEST,
            data: { qnaId: qna.id }
        });
    }, [id]);



    return (
        <div style={{ marginBottom: 20 }}>
            <Link to={`/qna/${qna.id}`}>
                <Comment
                    // cover={qna.PImages[0] && <QnaImage images={qna.Images} />}
                    actions={[

                        <Popover
                            key="more"
                            content={(
                                <Button.Group>
                                    {id && qna.User.id === id && qna.User.role === 'admin'
                                        ? (
                                            <>

                                                <Button type="danger" loading={removeQnaLoading} onClick={onRemoveQna}>삭제</Button>
                                            </>
                                        )
                                        : <></>}
                                </Button.Group>
                            )}
                        >
                            <EllipsisOutlined />
                        </Popover>,
                    ]}
                    author={qna.user.name}
                    datetime={<p>{moment(qna.createdAt).format('YYYY.MM.DD')}</p>}
                    content={
                        <>
                            <b>{qna.title}</b>
                            <br></br>

                            <p>
                                {qna.content}
                            </p>
                        </>
                    }
                >
                    <p>{qna.title}</p>
                    <p>{qna.content}</p>
                    <p>{moment(qna.createdAt).format('YYYY.MM.DD')}</p>

                </Comment>
            </Link>
        </div>
    );
};

QnaCard.propTypes = {

};

export default QnaCard;