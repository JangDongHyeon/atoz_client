
import React, { useCallback, useEffect, useState } from 'react';
import { render } from 'react-dom';
import { Modal, Select, Checkbox, Input, Button, Form } from 'antd';
import AppLayout from '../components/AppLayout';
import { useDispatch, useSelector } from 'react-redux';
import { GET_CONU_TRAN_REQUEST, INVOICE_SEARCH_REQUEST, USER_UPDATE_REQUEST } from '../actions/types';
import useInput from '../hooks/useInput';
const { Option } = Select;
const Home = () => {

    const [showModal, setShowModal] = useState(false);
    const [country, setCountry] = useState([]);
    const [weight, setWeight] = useState('1');
    const [transit, setTransit] = useState([]);
    const [checkbx, setChecBx] = useState(false)
    const dispatch = useDispatch();
    const { me, countrys, transits } = useSelector((state) => state.user);
    const { searchInvoicesLoading, searchInvoicesDone } = useSelector((state) => state.invoice);

    const [invoiceNumber, onChangeInvoiceNumber] = useInput('');
    const HAS_VISITED_BEFORE = localStorage.getItem('hasVisitedBefore');

    useEffect(() => {
        const handleShowModal = () => {
            if (HAS_VISITED_BEFORE && HAS_VISITED_BEFORE > new Date()) {
                return;
            }

            if (!HAS_VISITED_BEFORE) {
                setShowModal(true);
                // let expires = new Date();
                // expires = expires.setHours(expires.getHours() + 24);
                // localStorage.setItem('hasVisitedBefore', expires);
            }
        };
        if (me && me.Countryed.length === 0)
            window.setTimeout(handleShowModal, 2000);
    }, [HAS_VISITED_BEFORE, me]);

    useEffect(() => {
        dispatch({
            type: GET_CONU_TRAN_REQUEST
        })
    }, [])


    // const onSubmit = useCallback(() => {


    //     dispatch({
    //         type: USER_UPDATE_REQUEST,
    //         data: { country, weight, transit },
    //     });
    // }, [country, weight, transit]);


    const handleClose = () => {
        setShowModal(false)
        if (checkbx) {
            let expires = new Date();
            expires = expires.setHours(expires.getHours() + 24);
            localStorage.setItem('hasVisitedBefore', expires);
        }
    };

    const handleChangeSelect = (e, i, name) => {

        if (name === 'country') {


            setCountry(e)
        }
        else if (name === 'weight') {
            setWeight(e)
        }
        else if (name === 'transit') {


            setTransit(e)
        }

    }


    const onSubmit = useCallback(() => {


        dispatch({
            type: INVOICE_SEARCH_REQUEST,
            data: { invoiceNumber },
        });
    }, [invoiceNumber]);



    const checkOnChange = (e) => {
        console.log(`checked = ${e.target.checked}`);
        setChecBx(e.target.checked)

    }

    const handleOk = useCallback(() => {
        setShowModal(false);

        dispatch({
            type: USER_UPDATE_REQUEST,
            data: { country, weight, transit },
        });
    }, [country, weight, transit]);

    return (
        <AppLayout>
            {showModal && countrys && transits &&
                <Modal title="Basic Modal" visible={showModal} onOk={handleOk} onCancel={handleClose}>
                    {/* <Form onFinish={onSubmit}> */}
                    <div>
                        <label>주요발송국가</label>
                        {/* 
                        <Select defaultValue={country} style={{ width: 120 }} onChange={(e) => handleChangeSelect(e, 'country')}>
                            <Option value="us">미국</Option>
                            <Option value="can">캐나다</Option>

                        </Select>
                         */}
                        <br />
                        <Checkbox.Group options={countrys} onChange={(e, i) => handleChangeSelect(e, i, 'country')} />
                    </div>

                    <div>
                        <label>운송사</label>
                        <br />
                        {/* <Select defaultValue={transit} style={{ width: 120 }} onChange={(e) => handleChangeSelect(e, 'transit')}>
                            <Option value='ups'>UPS</Option>
                            <Option value='dps'>DPS</Option>

                        </Select>
                         */}
                        <Checkbox.Group options={transits} onChange={(e, i) => handleChangeSelect(e, i, 'transit')} />
                    </div>
                    <div>
                        <label>무게대</label>
                        <br />
                        <Select defaultValue={weight} style={{ width: 120 }} onChange={(e, i) => handleChangeSelect(e, i, 'weight')}>
                            <Option value='0'>1~10kg</Option>
                            <Option value='1'>11~20kg</Option>
                            <Option value='2'>31~40kg</Option>
                            <Option value='3'>41~50kg</Option>
                        </Select>
                    </div>


                    <div>

                    </div>
                    {/* <div style={{ marginTop: 10 }}>
                            <Button type="primary" htmlType="submit" loading={profileUpdateLoading}>입력</Button>
                        </div> */}

                    <Checkbox onChange={checkOnChange}>24시간동안 안보기</Checkbox>
                    {/* </Form> */}

                </Modal>}
            <Form onFinish={onSubmit}>
                <div>
                    <label htmlFor="user-email">송장번호 검색</label>
                    <br />
                    <Input value={invoiceNumber} required onChange={onChangeInvoiceNumber} />
                </div>
                <div style={{ marginTop: 10 }}>
                    <Button type="primary" htmlType="submit" loading={searchInvoicesLoading}>로그인</Button>
                </div>
            </Form>
        </AppLayout>
    );
};

Home.propTypes = {};

export default Home;