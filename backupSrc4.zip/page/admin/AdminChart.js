import React, { useEffect, useState, } from 'react';
import { Radio } from 'antd';
import AppLayout from '../../components/AppLayout';
import { useDispatch, useSelector } from 'react-redux';
import { INVOICE_CHART_ADMIN_GET_REQUEST } from '../../actions/types';

import { ResponsivePie } from '@nivo/pie'
import Admin from '../../components/auth/Admin';

const AdminChart = props => {

    const dispatch = useDispatch();
    const { me } = useSelector((state) => state.user);
    const [date, setDate] = useState('yesterday')
    const { loadAdminInvoicesChatsLoading, chartC, chartT } = useSelector((state) => state.invoice);
    console.log(chartC)

    useEffect(() => {
        dispatch({
            type: INVOICE_CHART_ADMIN_GET_REQUEST,
            data: { date: 'yesterday' }
        })
    }, [me])

    const onChange = e => {

        setDate(e.target.value);
        dispatch({
            type: INVOICE_CHART_ADMIN_GET_REQUEST,
            data: { date: e.target.value }
        })
    };

    return me && (chartC.length > 0 && chartT.length > 0) ? (
        <Admin>
            <AppLayout>

                <div style={{ height: 300, width: 500 }}>
                    <ResponsivePie
                        data={chartC}
                        margin={{ top: 40, right: 80, bottom: 80, left: 80 }}
                        startAngle={-75}
                        innerRadius={0.5}
                        padAngle={0.7}
                        cornerRadius={3}
                        activeOuterRadiusOffset={8}
                        colors={{ scheme: 'nivo' }}
                        borderWidth={1}
                        borderColor={{ from: 'color', modifiers: [['darker', 0.2]] }}
                        arcLinkLabelsSkipAngle={10}
                        arcLinkLabelsTextColor="#333333"
                        arcLinkLabelsThickness={2}
                        arcLinkLabelsColor={{ from: 'color' }}
                        arcLabelsSkipAngle={10}
                        arcLabelsTextColor={{ from: 'color', modifiers: [['darker', 2]] }}
                        defs={[
                            {
                                id: 'dots',
                                type: 'patternDots',
                                background: 'inherit',
                                color: 'rgba(255, 255, 255, 0.3)',
                                size: 4,
                                padding: 1,
                                stagger: true
                            },
                            {
                                id: 'lines',
                                type: 'patternLines',
                                background: 'inherit',
                                color: 'rgba(255, 255, 255, 0.3)',
                                rotation: -45,
                                lineWidth: 6,
                                spacing: 10
                            }
                        ]}
                        fill={[
                            {
                                match: {
                                    id: 'CAN'
                                },
                                id: 'dots'
                            },
                            {
                                match: {
                                    id: 'USA'
                                },
                                id: 'dots'
                            },
                        ]}
                        legends={[
                            {
                                anchor: 'bottom',
                                direction: 'row',
                                justify: false,
                                translateX: 0,
                                translateY: 56,
                                itemsSpacing: 0,
                                itemWidth: 100,
                                itemHeight: 18,
                                itemTextColor: '#999',
                                itemDirection: 'left-to-right',
                                itemOpacity: 1,
                                symbolSize: 18,
                                symbolShape: 'circle',
                                effects: [
                                    {
                                        on: 'hover',
                                        style: {
                                            itemTextColor: '#000'
                                        }
                                    }
                                ]
                            }
                        ]}
                    />
                </div>
                <Radio.Group onChange={onChange} value={date}>
                    <Radio value={'yesterday'}>yesterday</Radio>
                    <Radio value={'week'}>week</Radio>
                    <Radio value={'oneMonthAgo'}>oneMonthAgo</Radio>
                    <Radio value={'oneYearAgo'}>oneYearAgo</Radio>
                </Radio.Group>
                <div style={{ height: 300, width: 500 }}>
                    <ResponsivePie
                        data={chartT}
                        margin={{ top: 40, right: 80, bottom: 80, left: 80 }}
                        startAngle={-75}
                        innerRadius={0.5}
                        padAngle={0.7}
                        cornerRadius={3}
                        activeOuterRadiusOffset={8}
                        colors={{ scheme: 'nivo' }}
                        borderWidth={1}
                        borderColor={{ from: 'color', modifiers: [['darker', 0.2]] }}
                        arcLinkLabelsSkipAngle={10}
                        arcLinkLabelsTextColor="#333333"
                        arcLinkLabelsThickness={2}
                        arcLinkLabelsColor={{ from: 'color' }}
                        arcLabelsSkipAngle={10}
                        arcLabelsTextColor={{ from: 'color', modifiers: [['darker', 2]] }}
                        defs={[
                            {
                                id: 'dots',
                                type: 'patternDots',
                                background: 'inherit',
                                color: 'rgba(255, 255, 255, 0.3)',
                                size: 4,
                                padding: 1,
                                stagger: true
                            },
                            {
                                id: 'lines',
                                type: 'patternLines',
                                background: 'inherit',
                                color: 'rgba(255, 255, 255, 0.3)',
                                rotation: -45,
                                lineWidth: 6,
                                spacing: 10
                            }
                        ]}
                        fill={[
                            {
                                match: {
                                    id: 'UPS'
                                },
                                id: 'dots'
                            },
                            {
                                match: {
                                    id: 'EMS'
                                },
                                id: 'dots'
                            },
                        ]}
                        legends={[
                            {
                                anchor: 'bottom',
                                direction: 'row',
                                justify: false,
                                translateX: 0,
                                translateY: 56,
                                itemsSpacing: 0,
                                itemWidth: 100,
                                itemHeight: 18,
                                itemTextColor: '#999',
                                itemDirection: 'left-to-right',
                                itemOpacity: 1,
                                symbolSize: 18,
                                symbolShape: 'circle',
                                effects: [
                                    {
                                        on: 'hover',
                                        style: {
                                            itemTextColor: '#000'
                                        }
                                    }
                                ]
                            }
                        ]}
                    />
                </div>
            </AppLayout>
        </Admin>
    ) : <>
        <Radio.Group onChange={onChange} value={date}>
            <Radio value={'yesterday'}>yesterday</Radio>
            <Radio value={'week'}>week</Radio>
            <Radio value={'oneMonthAgo'}>oneMonthAgo</Radio>
            <Radio value={'oneYearAgo'}>oneYearAgo</Radio>
        </Radio.Group>
    </>;

};

AdminChart.propTypes = {

};

export default AdminChart;